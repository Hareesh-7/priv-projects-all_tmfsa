<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<form action="target_file_post.php" method="POST">
	Name: <input type="text" name="name"/><br><br>
	Last Name: <input type="text" name="last_name"/><br><br>
	Email: <input type="text" name="email"/><br><br>
	Phone Number: <input type="text" name="phone_number"/><br><br>
	<input name="submit_form" type="submit"/>
	</form>
</body>
</html>