
<?php
    include("connection.php");
    if(isset($_POST['submit'])) {
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $mobileNumber = $_POST['mobileNumber'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $userType = $_POST['userType'];

        if (isset($_FILES['profilePic'])){
            $picName = $_FILES['profilePic']['name'];
            $picTmp = $_FILES['profilePic']['tmp_name'];
            $picPath = 'profiles/'.$picName;
    
            move_uploaded_file($picTmp,$picPath);
        }

        if (isset($_FILES['updatedResume'])){
            $resumeName = $_FILES['updatedResume']['name'];
            $resumeTmp = $_FILES['updatedResume']['tmp_name'];
            $resumePath = 'profiles/'.$resumeName;
    
            move_uploaded_file($resumeTmp,$resumePath);
        }    
    }
    $sql="insert into sign_in (firstName, lastName, mobileNumber, email, password, userType, profilePic, updatedResume) values(?,?,?,?,?,?,?,?)";
    $stmt=$conn->prepare($sql);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $data=array($firstName,$lastName,$mobileNumber,$email,$password, $userType, $picName, $resumeName);
    // var_dump($data);
    $stmt->execute($data);

    echo("form submited");
    header('location:login.php');
?>

