<?php
include_once('connection.php');
$email = $_GET['email'];
$query = "select * from sign_in where email = '".$email."'";

$result = $conn->query($query);

$row = $result->fetch(PDO::FETCH_ASSOC);

?>

<!doctype html>
<html>
<head>
	<title>Update Document</title>
</head>

<body>
	<div>
        <h1>Update Form</h1>
        <form action="update_form.php" method="post" enctype="multipart/form-data">
            <table>
            <tr>
                    <th>First  Name</th><th>:</th><td><input type="text" name="firstName" value="<?php echo $row['firstName']; ?>"></td>
                </tr>
                <tr>
                    <th>Last  Name</th><th>:</th><td><input type="text" name="lastName" value="<?php echo $row['lastName']; ?>"></td>
                </tr>
                <tr>
                    <th>Mobile Number</th><th>:</th><td><input type="number" name="mobileNumber" value="<?php echo $row['mobileNumber']; ?>"></td>
                </tr>
                <tr>
                    <th>Email ID</th><th>:</th><td><input type="email" name="email" value="<?php echo $row['email']; ?>"></td>
                </tr>
                <tr>
                    <th>Password</th><th>:</th><td><input type="text" name="password" value="<?php echo $row['password']; ?>"></td>
                </tr>
                <tr>
                    <th>Profile_Pic</th><th>:</th><td><input type="file" name="profilePic" value="<?php echo $row['profilePic']; ?>"></td>
                </tr>
                <tr>
                    <th>Resume</th><th>:</th><td><input type="file" name="updatedResume" value="<?php echo $row['updatedResume']; ?>"></td>
                </tr>
                <tr>
                    <th>User Type</th><th>:</th><td><select name="userType" value="<?php echo $row['userType']; ?>">
                                                        <option>User</option>
                                                        <option>Admin</option>
                                                    </select>
                                                </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <input type="submit" value="Update" name="update">
                        <input type="reset" value="Reset" name="reset">
                    </td>
                </tr>
            </table>
        </form>
	</div>
</body>
</html>