<?php
include_once('connection.php');
  $email = $_GET['email'];
  $query = "delete from sign_in where email='".$email."'";

$conn->exec($query);
  echo "Record deleted successfully";
  header('location:crud.php');
?>
 