<?php
	include('connection.php');
	echo $sql = "select * from sign_in";
	$result = $conn->query($sql);
?>
<!doctype html>
<html>
<head>
	<title>CRUD</title>
</head>

<body>
    <form method="POST" >
			<h1>CRUD table</h1>
				<table border="1">
					<tr style="text-align: center;">
                        <td>First Name</td>
                        <td>Last Name</td>
						<td>Phone_Number</td>
						<td>Email ID</td>
						<td>Password</td>
						<td>Profile Photo</td>
                        <td>Resume </td>
						<td>Delete</td>
						<td>Update/Modify</td>
					</tr>
					<?php
						$count=$result->rowCount();
					if ($count > 0) {
						while ($row=$result->fetch(PDO::FETCH_ASSOC)) {
							echo "<tr>
                                    <td>".$row['firstName']."</td>
                                    <td>".$row['lastName']."</td>
                                    <td>".$row['mobileNumber']."</td>
									<td>".$row['email']."</td>
									<td>".$row['password']."</td>
									<td><img name=preview src=profiles/".$row['profilePic']." style='width:10rem'></td>
									<td><img name=preview src=profiles/".$row['updatedResume']." style='width:10rem'></td>
									<td><a href=delete.php?email=".$row['email']." name=delete>delete</a></td>
									<td><a href=update.php?email=".$row['email']." name=update>Update</a></td>
								</tr>" ;
						}
					}
					else {
						echo "Details not found" ;
					}

					?>
				</table>
			</form>
</body>
</html>