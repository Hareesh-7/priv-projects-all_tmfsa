<html>
    <head>
        <title>Evolution Task</title>
    </head>
    <body>
        <form action="submit_form.php" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <th colspan="3">
                        Sign UP Form
                    </th>
                </tr>
                <tr>
                    <th> First Name </th>
                    <th> : </th>
                    <td>
                        <input type="text" name="firstName" />
                    </td>
                </tr>
                <tr>
                    <th> Last Name </th>
                    <th> : </th>
                    <td>
                        <input type="text" name="lastName" />
                    </td>
                </tr>
                <tr>
                    <th>  Email </th>
                    <th> : </th>
                    <td>
                        <input type="email" name="email" />
                    </td>
                </tr>
                <tr>
                    <th> Mobile Number </th>
                    <th> : </th>
                    <td>
                        <input type="number" name="mobileNumber" />
                    </td>
                </tr>
                <tr>
                    <th> Password </th>
                    <th> : </th>
                    <td>
                        <input type="password" name="password" />
                    </td>
                </tr>
                <tr>
                    <th> Profile Photo </th>
                    <th> : </th>
                    <td>
                        <input type="file" name="profilePic" />
                    </td>
                </tr>
                <tr>
                    <th> Resume </th>
                    <th> : </th>
                    <td>
                        <input type="file" name="updatedResume" />
                    </td>
                </tr>
                <tr>
                    <th> User Type </th>
                    <th> : </th>
                    <td>
                        <select name="userType" >
                            <option>User</option>
                            <option>Admin</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th> 
                        <input type="reset" name="reset" />    
                    </th>
                    <th></th>
                    <td>
                        <input type="submit" name="submit" />
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <tr>
						<td colspan="3">
							If already registred <a href="login.php">click here</a> to log_in.
						</td>
					</tr>
                </tr>
            </table>
        </form>
    </body>
</html>
