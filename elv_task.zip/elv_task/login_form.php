<?php
    include('connection.php');
    if (isset($_POST['submit'])){
         $email = $_POST['email'];
         $password = $_POST['password'];
    }
    
    $query = "select * from sign_in where email = '".$email."' and password='".$password."'";

    $result = $conn->query($query);

    if ($result->rowCount() > 0) {
        session_start();
        $row = $result->fetch(PDO::FETCH_ASSOC);
        $_SESSION['sign_in'] = $row['email'];

        if ($row['userType'] == "User") {
            header('location:signUP.php');
        }
        else{
            header('location:crud.php');
        }

    }  
  else{
	  echo("No user Found");
        header('location:login.php');
    }
?>
