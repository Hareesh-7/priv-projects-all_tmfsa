<?php
    include('connection.php');
    if (isset($_POST['update'])){
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $mobileNum = $_POST['mobileNumber'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $userType = $_POST['userType'];
        $profilePic = $_POST['profilePic'];
        $updatedResume = $_POST['updatedResume'];
    }

   	$sql = "update sign_in set firstName='".$firstName."', lastName='".$lastName."', mobileNumber=".$mobileNum.",password= '".$password."', userType='".$userType."',profilePic='".$profilePic."', updatedResume='".$updatedResume."' where email='".$email."'";

   $result = $conn->query($sql);
      echo "User updated successfully";
?>