
<?php
    include('connection.php');
    if(isset($_POST['submit'])) {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $mobile_number = $_POST['mobile_number'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $user_type = "User";
    }

    if(isset($_FILES['file_name'])) {
        $fileName=$_FILES['file_name']['name'];
        $file_size =$_FILES['file_name']['size'];
        $file_temp = $_FILES['file_name']['tmp_name'];
        $file_type = $_FILES['file_name']['type'];
        $file_path = 'uploads/'.$fileName;

        move_uploaded_file($file_temp,$file_path);

    }
?>

<?php
    include('connection.php');
    if (isset($_POST['p4'])){
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $MobilePhone = $_POST['MobilePhone'];
        $mail = $_POST['mail'];
        $password = $_POST['password'];      
    }
    if (isset($_FILES['profilePic'])){
        $picName = $_FILES['profilePic']['name'];
        $picTmp = $_FILES['profilePic']['tmp_name'];
        $picPath = 'profiles/'.$picName;
    
        move_uploaded_file($picTmp,$picPath);
    }
    if (isset($_FILES['UpdatedResume'])){
        $resumeName = $_FILES['UpdatedResume']['name'];
        $resumeTmp = $_FILES['UpdatedResume']['tmp_name'];
        $resumePath = '/'.$resumeName;
    
        move_uploaded_file($resumeTmp,$resumePath);
    }
    $sql = "insert into users (firstName, lastName, email, mobilePhone, password, profilePic, updatedResume, userType) values(?,?,?,?,?,?,?,?)";
    $stmt =  $conn->prepare($sql);
    $data = array($firstName,$lastName,$mail,$MobilePhone,$password,$picName,$resumeName); 
    $stmt->execute($data);

    echo "Registration Successfull";
?>


