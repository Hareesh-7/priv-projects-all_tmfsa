<html>
    <head>
        <title>Evolution Task</title>
    </head>
    <body>
    <form action="login_form.php" method="post">
            <table>
                <tr>
                    <th colspan="3">
                        LogIN Form
                    </th>
                </tr>
                <tr>
                    <th>  Email </th>
                    <th> : </th>
                    <td>
                        <input type="email" name="email" />
                    </td>
                </tr>
                <tr>
                    <th> Password </th>
                    <th> : </th>
                    <td>
                        <input type="password" name="password" />
                    </td>
                </tr>
                <tr>
                    <th> 
                        <input type="reset" name="reset" />    
                    </th>
                    <th></th>
                    <td>
                        <input type="submit" name="submit" />
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <tr>
						<td colspan="3">
							If not registred <a href="signUP.php">click here</a> to Sign_UP.
						</td>
					</tr>
                </tr>
            </table>
        </form>
    </body>
</html>
